package com.aivle.mini7.model;

public class EmergencyModel {
}
