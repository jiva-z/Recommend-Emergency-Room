package com.aivle.mini7.repository;

public class HospitalRepository {
}
