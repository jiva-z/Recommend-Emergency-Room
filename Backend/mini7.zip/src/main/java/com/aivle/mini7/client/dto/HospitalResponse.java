package com.aivle.mini7.client.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class HospitalResponse {
    private int emergency_class;
}