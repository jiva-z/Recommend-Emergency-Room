package com.aivle.mini7.client.api;

public class FastApiClient {
}
