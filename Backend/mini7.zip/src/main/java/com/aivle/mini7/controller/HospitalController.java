package com.aivle.mini7.controller;

public class HospitalController {
}
